package com.mycompany.isabela.vitoria.ac2;

public class Pedido {
    private Integer codigo ;
    private String produto;
    private Integer quantidade ;
    private Double valorUnitario ;
    private Double valorComDesconto ;
    private Double valorTotal;
    private Boolean itemPromocional ;

   Pedido(){
       this.codigo = 000;
       this.quantidade = 00;
       this.valorComDesconto =0.00;
       this.valorTotal =0.00;
       this.valorUnitario =0.00;
       this.itemPromocional = false;
   }


    public void calcularValorTotal(){
        this.valorTotal= this.valorUnitario * this.quantidade;
        
    }

    @Override
    public String toString() {
        return (String.format("\nPedido:"+"\ncodigo:"+"\nproduto:"+"\nquantidade:"+"\nvalor unitario:"+ "\nquantidade:"+"\nvalor total:"+"\nItem promocional:"+"\nvalor com desconto:"+"\nTotal a ser pago:",
                produto,codigo,quantidade,valorUnitario,valorComDesconto,valorTotal,itemPromocional));
        
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(Double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public Double getValorComDesconto() {
        return valorComDesconto;
    }

    public void setValorComDesconto(Double valorComDesconto) {
        this.valorComDesconto = valorComDesconto;
    }

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Boolean getItemPromocional() {
        return itemPromocional;
    }

    public void setItemPromocional(Boolean itemPromocional) {
        this.itemPromocional = itemPromocional;
    }

}
